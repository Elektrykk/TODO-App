package com.example.todoapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.*;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private ArrayList<String> taskList = new ArrayList<>();
    private TaskAdapter taskAdapter;
    private String fileName = "tasks.txt";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText editTextTask = findViewById(R.id.editTextTask);
        Button buttonAddTask = findViewById(R.id.buttonAddTask);
        Button buttonDeleteSelected = findViewById(R.id.buttonDeleteSelected);
        RecyclerView recyclerViewTasks = findViewById(R.id.recyclerViewTasks);

        recyclerViewTasks.setLayoutManager(new LinearLayoutManager(this));
        taskAdapter = new TaskAdapter(taskList);
        recyclerViewTasks.setAdapter(taskAdapter);

        loadTasksFromFile();

        buttonAddTask.setOnClickListener(v -> {
            String task = editTextTask.getText().toString();
            if (!task.isEmpty()) {
                taskAdapter.addTask(task);
                editTextTask.setText("");
                saveTasksToFile();
            } else {
                Toast.makeText(this, "Wpisz treść zadania!", Toast.LENGTH_SHORT).show();
            }
        });

        buttonDeleteSelected.setOnClickListener(v -> {
            if (taskAdapter.hasSelectedTasks()) {
                taskAdapter.deleteSelectedTasks();
                saveTasksToFile();
            } else {
                Toast.makeText(this, "Nie zaznaczono żadnego zadania do usunięcia!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void loadTasksFromFile() {
        try (BufferedReader br = new BufferedReader(new InputStreamReader(openFileInput(fileName)))) {
            String line;
            while ((line = br.readLine()) != null) {
                taskList.add(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void saveTasksToFile() {
        try (BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(openFileOutput(fileName, MODE_PRIVATE)))) {
            for (String task : taskList) {
                bw.write(task);
                bw.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
